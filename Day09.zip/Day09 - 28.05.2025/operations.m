function [add,sub,mul,div] = operations (x, y)
    add = x + y;
    sub = x - y;
    mul = x * y;
    div = x / y;
end 
