function myFunction()
   disp('Hello, this function has no inputs and no outputs');
end