n = input('Enter a number: ');
    fact = 1; 
    for i = 1:n
        fact= fact * i;
    end
    disp(fact);