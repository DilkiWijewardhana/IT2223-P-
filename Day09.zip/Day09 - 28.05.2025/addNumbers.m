function sum = addNumbers(x, y)
    sum = x + y;
end
%this function input and output